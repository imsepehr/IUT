#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>

#define DEVICE_PATH "/dev/headset"
#define BUFFER_SIZE 128

int main() 
{
    int fd = open(DEVICE_PATH, O_RDWR); 

    if (fd < 0) 
    {
        perror("Failed to open the headset");
        return errno;
    }

    const char *messages[] = {"Sepehr Ebadi", "Test 2", "Copmuter Engineering Programmer in IUT aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"};
    for (int i = 0; i < 3; i++) 
    {
        printf("Writing to headset: %s\n", messages[i]);
        if (write(fd, messages[i], strlen(messages[i])) < 0) 
        {
            perror("Failed to write to the headset");
            close(fd);
            return errno;
        }
    }

    int read_sizes[] = {16, 32, 64};
    for (int i = 0; i < 3; i++) 
    {
        char read_data[BUFFER_SIZE] = {0}; 

        ssize_t bytes_read = read(fd, read_data, read_sizes[i]);
        if (bytes_read < 0) 
        {
            perror("Failed to read from the headset");
            close(fd);
            return errno;
        }

        printf("Data read (%ld bytes): ", bytes_read);

        for (int j = 0; j < bytes_read; j++) 
        {
            printf("%02x ", (unsigned char)read_data[j]); 
        }
        printf("\n");
    }

    close(fd);  
    return 0;
}
