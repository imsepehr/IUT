#!/bin/bash
make
gcc -o User User.c
sudo insmod headset.ko
sudo mknod /dev/headset c 507 0
echo "Module installed and node created."
