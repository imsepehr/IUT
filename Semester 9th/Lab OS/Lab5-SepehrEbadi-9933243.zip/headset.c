#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/random.h>

#define DEVICE_NAME "headset"
#define BUFFER_SIZE 100     
#define PRINT_THRESHOLD 5
MODULE_LICENSE("GPL");


static char kernel_buffer[BUFFER_SIZE];
static int buffer_pos = 0;
static int major_number;
static int is_device_open = 0; 

// Write
static ssize_t device_write(struct file *file, const char __user *user_buffer, size_t len, loff_t *offset) 
{
    if (len > BUFFER_SIZE - buffer_pos)
        len = BUFFER_SIZE - buffer_pos;

    if (copy_from_user(kernel_buffer + buffer_pos, user_buffer, len) != 0)
        return -EFAULT;
    
    buffer_pos += len;
    
    if (buffer_pos >= PRINT_THRESHOLD) 
    {
        kernel_buffer[buffer_pos] = '\0';
        printk(KERN_INFO "copy from user :  %s\n", kernel_buffer);
        buffer_pos = 0;
    }

    return len;
}

// Read
static ssize_t device_read(struct file *file, char __user *user_buffer, size_t len, loff_t *offset) 
{
    char random_data[BUFFER_SIZE];
    if (len > BUFFER_SIZE) 
        len = BUFFER_SIZE;
    
    get_random_bytes(random_data, len);
    if (copy_to_user(user_buffer, random_data, len) != 0) return -EFAULT;
    
    printk(KERN_INFO "copy to user.\n");
    return len;
}

// Open
static int device_open(struct inode *inode, struct file *file) 
{
    if (is_device_open) return -EBUSY;
    is_device_open++;
    try_module_get(THIS_MODULE);
    return 0;
}

// Close
static int device_release(struct inode *inode, struct file *file) 
{
    is_device_open--;
    module_put(THIS_MODULE);
    return 0;
}

static struct file_operations fops = 
{
    .open = device_open,
    .release = device_release,
    .write = device_write,
    .read = device_read,
};

static int __init headset_init(void) 
{
    major_number = register_chrdev(0, DEVICE_NAME, &fops);
    if (major_number < 0) 
    {
        printk(KERN_ALERT "Headset module failed with major number %d\n", major_number);
        return major_number;
    }
    printk(KERN_INFO "Headset module loaded with device major number %d\n", major_number);
    return 0;
}

static void __exit headset_exit(void) 
{
    unregister_chrdev(major_number, DEVICE_NAME);
    printk(KERN_INFO "Headset module unloaded.\n");
}

module_init(headset_init);
module_exit(headset_exit);

