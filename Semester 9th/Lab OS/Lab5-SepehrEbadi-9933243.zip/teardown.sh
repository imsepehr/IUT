#!/bin/bash
sudo rmmod headset
sudo rm /dev/headset
make clean
sudo rm User
echo "Module removed and node deleted."
