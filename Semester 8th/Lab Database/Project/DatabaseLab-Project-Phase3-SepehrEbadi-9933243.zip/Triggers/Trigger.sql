﻿---1
CREATE TRIGGER UpdatePositionTrigger
ON Employees
AFTER UPDATE
AS
BEGIN
    IF UPDATE(Position)
    BEGIN
        DECLARE @EmployeeID INT;
        DECLARE @NewPosition VARCHAR(100);
        
        SELECT @EmployeeID = inserted.Employee_ID, @NewPosition = inserted.Position
        FROM inserted;
        
        IF @NewPosition = 'CEO'
        BEGIN
            PRINT 'Attention: Employee ' + CAST(@EmployeeID AS VARCHAR(10)) + ' has been promoted to CEO.';
        END
    END
END;

ALTER TABLE Employees ENABLE TRIGGER UpdatePositionTrigger;

UPDATE Employees
SET Position = 'CEO'
WHERE Employee_ID = 27;  

---2

CREATE TABLE Log_Festivals (
    Log_ID INT PRIMARY KEY IDENTITY(1,1),
    EventDescription VARCHAR(255),
    EventDate DATETIME
);

CREATE TRIGGER InsertFestivalTrigger
ON Festivals
AFTER INSERT
AS
BEGIN
    -- اضافه کردن وقایع ورودی به جدول لاگ
    DECLARE @EventDescription NVARCHAR(255);
    DECLARE @EventDate DATETIME;

    SELECT @EventDescription = 'A new festival has been added.',
           @EventDate = GETDATE();

    INSERT INTO Log_Festivals (EventDescription, EventDate)
    VALUES (@EventDescription, @EventDate);
END;

ALTER TABLE Festivals ENABLE TRIGGER InsertFestivalTrigger;

INSERT INTO Festivals (Subject, Name, Description, Date, Location)
VALUES ('تست تریگر2', '2تریگر', 'The largest technology exhibition of the year.', '2024-09-15', 'New York');

select * from Log_Festivals;

---3
DROP TRIGGER IF EXISTS DeleteLogTrigger;

CREATE TRIGGER DeleteLogTrigger
ON Festivals
AFTER DELETE
AS
BEGIN
    DECLARE @EventDescription NVARCHAR(255);
    DECLARE @EventDate DATETIME;

    SELECT @EventDescription = 'A festival has been deleted.',
           @EventDate = GETDATE();

    INSERT INTO Log_Festivals (EventDescription, EventDate)
    VALUES (@EventDescription, @EventDate);
END;

ENABLE TRIGGER DeleteLogTrigger ON Festivals;


DELETE FROM Festivals WHERE Festival_ID = 49;

select * from Log_Festivals;
