﻿---1
CREATE FUNCTION GetEmployeesByCompanyName (@CompanyName VARCHAR(255))
RETURNS TABLE
AS
RETURN
(
    SELECT e.*
    FROM Employees e
    INNER JOIN Companies c ON e.Company_ID = c.Company_ID
    WHERE c.Name = @CompanyName
);

SELECT * FROM GetEmployeesByCompanyName('شرکت 5');

---2
DROP FUNCTION IF EXISTS GetCEOCompanies;  
GO

CREATE FUNCTION GetCEOCompanies(@CompanyName VARCHAR(255))
RETURNS TABLE
AS
RETURN
(
    SELECT E.*
    FROM Employees E 
    JOIN Companies C ON C.Company_ID = E.Company_ID
    WHERE C.Name = @CompanyName and E.Position = 'CEO'
);

SELECT * FROM GetCEOCompanies('شرکت 3');


---3
CREATE FUNCTION dbo.GetAverageSalary(@CompanyID INT)
RETURNS DECIMAL(18, 2)
AS
BEGIN
    DECLARE @AverageSalary DECIMAL(18, 2);

    SELECT @AverageSalary = AVG(Salary)
    FROM Employees
    WHERE Company_ID = @CompanyID;

    RETURN @AverageSalary;
END;

DECLARE @CompanyID INT = 5;    
SELECT dbo.GetAverageSalary(@CompanyID) AS AverageSalary;
