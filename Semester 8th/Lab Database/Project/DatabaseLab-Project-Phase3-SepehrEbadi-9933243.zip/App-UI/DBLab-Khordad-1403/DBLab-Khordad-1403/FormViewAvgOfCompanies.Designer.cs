﻿namespace DBLab_Khordad_1403
{
    partial class FormViewAvgOfCompanies
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblChildForm = new Label();
            btnLoad = new Button();
            btnX = new Button();
            dataGridViewAvgSalary = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dataGridViewAvgSalary).BeginInit();
            SuspendLayout();
            // 
            // lblChildForm
            // 
            lblChildForm.AutoSize = true;
            lblChildForm.FlatStyle = FlatStyle.Flat;
            lblChildForm.Font = new Font("Georgia", 18F, FontStyle.Bold, GraphicsUnit.Point);
            lblChildForm.ForeColor = Color.Gainsboro;
            lblChildForm.Location = new Point(161, 31);
            lblChildForm.Name = "lblChildForm";
            lblChildForm.Size = new Size(465, 35);
            lblChildForm.TabIndex = 62;
            lblChildForm.Text = "Average Salary of Companies";
            // 
            // btnLoad
            // 
            btnLoad.FlatStyle = FlatStyle.Flat;
            btnLoad.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            btnLoad.ForeColor = Color.Gainsboro;
            btnLoad.Location = new Point(565, 363);
            btnLoad.Name = "btnLoad";
            btnLoad.Size = new Size(94, 29);
            btnLoad.TabIndex = 61;
            btnLoad.Text = "Load";
            btnLoad.UseVisualStyleBackColor = true;
            btnLoad.Click += btnLoad_Click;
            // 
            // btnX
            // 
            btnX.FlatStyle = FlatStyle.Flat;
            btnX.ForeColor = Color.Gainsboro;
            btnX.Location = new Point(33, 39);
            btnX.Name = "btnX";
            btnX.Size = new Size(94, 29);
            btnX.TabIndex = 60;
            btnX.Text = "X";
            btnX.UseVisualStyleBackColor = true;
            btnX.Click += btnX_Click;
            // 
            // dataGridViewAvgSalary
            // 
            dataGridViewAvgSalary.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewAvgSalary.Location = new Point(130, 82);
            dataGridViewAvgSalary.Name = "dataGridViewAvgSalary";
            dataGridViewAvgSalary.RowHeadersWidth = 51;
            dataGridViewAvgSalary.RowTemplate.Height = 29;
            dataGridViewAvgSalary.Size = new Size(425, 270);
            dataGridViewAvgSalary.TabIndex = 59;
            // 
            // FormViewAvgOfCompanies
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(32, 30, 45);
            ClientSize = new Size(693, 428);
            Controls.Add(lblChildForm);
            Controls.Add(btnLoad);
            Controls.Add(btnX);
            Controls.Add(dataGridViewAvgSalary);
            Name = "FormViewAvgOfCompanies";
            Text = "FormViewAvgOfCompanies";
            ((System.ComponentModel.ISupportInitialize)dataGridViewAvgSalary).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblChildForm;
        private Button btnLoad;
        private Button btnX;
        private DataGridView dataGridViewAvgSalary;
    }
}