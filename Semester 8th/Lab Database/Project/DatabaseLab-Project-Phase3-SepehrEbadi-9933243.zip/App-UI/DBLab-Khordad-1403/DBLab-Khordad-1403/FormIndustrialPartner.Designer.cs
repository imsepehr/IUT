﻿namespace DBLab_Khordad_1403
{
    partial class FormIndustrialPartner
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblChildForm = new Label();
            btnLoad = new Button();
            btnX = new Button();
            dataGridIndPartner = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dataGridIndPartner).BeginInit();
            SuspendLayout();
            // 
            // lblChildForm
            // 
            lblChildForm.AutoSize = true;
            lblChildForm.FlatStyle = FlatStyle.Flat;
            lblChildForm.Font = new Font("Georgia", 18F, FontStyle.Bold, GraphicsUnit.Point);
            lblChildForm.ForeColor = Color.Gainsboro;
            lblChildForm.Location = new Point(218, 38);
            lblChildForm.Name = "lblChildForm";
            lblChildForm.Size = new Size(315, 35);
            lblChildForm.TabIndex = 22;
            lblChildForm.Text = "Industrial Partners";
            // 
            // btnLoad
            // 
            btnLoad.FlatStyle = FlatStyle.Flat;
            btnLoad.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            btnLoad.ForeColor = Color.Gainsboro;
            btnLoad.Location = new Point(565, 362);
            btnLoad.Name = "btnLoad";
            btnLoad.Size = new Size(94, 29);
            btnLoad.TabIndex = 21;
            btnLoad.Text = "Load";
            btnLoad.UseVisualStyleBackColor = true;
            btnLoad.Click += btnLoad_Click;
            // 
            // btnX
            // 
            btnX.FlatStyle = FlatStyle.Flat;
            btnX.ForeColor = Color.Gainsboro;
            btnX.Location = new Point(33, 38);
            btnX.Name = "btnX";
            btnX.Size = new Size(94, 29);
            btnX.TabIndex = 20;
            btnX.Text = "X";
            btnX.UseVisualStyleBackColor = true;
            btnX.Click += btnX_Click;
            // 
            // dataGridIndPartner
            // 
            dataGridIndPartner.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridIndPartner.Location = new Point(33, 86);
            dataGridIndPartner.Name = "dataGridIndPartner";
            dataGridIndPartner.RowHeadersWidth = 51;
            dataGridIndPartner.RowTemplate.Height = 29;
            dataGridIndPartner.Size = new Size(626, 270);
            dataGridIndPartner.TabIndex = 19;
            // 
            // FormIndustrialPartner
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(32, 30, 45);
            ClientSize = new Size(693, 428);
            Controls.Add(lblChildForm);
            Controls.Add(btnLoad);
            Controls.Add(btnX);
            Controls.Add(dataGridIndPartner);
            Name = "FormIndustrialPartner";
            Text = "FormIndustrialPartner";
            ((System.ComponentModel.ISupportInitialize)dataGridIndPartner).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblChildForm;
        private Button btnLoad;
        private Button btnX;
        private DataGridView dataGridIndPartner;
    }
}