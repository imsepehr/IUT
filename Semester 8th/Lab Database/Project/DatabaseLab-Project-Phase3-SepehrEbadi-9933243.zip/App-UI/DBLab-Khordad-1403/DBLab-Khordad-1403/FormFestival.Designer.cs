﻿namespace DBLab_Khordad_1403
{
    partial class FormFestival
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblChildForm = new Label();
            btnLoad = new Button();
            btnX = new Button();
            dataGridFestival = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dataGridFestival).BeginInit();
            SuspendLayout();
            // 
            // lblChildForm
            // 
            lblChildForm.AutoSize = true;
            lblChildForm.FlatStyle = FlatStyle.Flat;
            lblChildForm.Font = new Font("Georgia", 18F, FontStyle.Bold, GraphicsUnit.Point);
            lblChildForm.ForeColor = Color.Gainsboro;
            lblChildForm.Location = new Point(285, 37);
            lblChildForm.Name = "lblChildForm";
            lblChildForm.Size = new Size(135, 35);
            lblChildForm.TabIndex = 38;
            lblChildForm.Text = "Festival";
            // 
            // btnLoad
            // 
            btnLoad.FlatStyle = FlatStyle.Flat;
            btnLoad.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            btnLoad.ForeColor = Color.Gainsboro;
            btnLoad.Location = new Point(565, 362);
            btnLoad.Name = "btnLoad";
            btnLoad.Size = new Size(94, 29);
            btnLoad.TabIndex = 37;
            btnLoad.Text = "Load";
            btnLoad.UseVisualStyleBackColor = true;
            btnLoad.Click += btnLoad_Click;
            // 
            // btnX
            // 
            btnX.FlatStyle = FlatStyle.Flat;
            btnX.ForeColor = Color.Gainsboro;
            btnX.Location = new Point(33, 38);
            btnX.Name = "btnX";
            btnX.Size = new Size(94, 29);
            btnX.TabIndex = 36;
            btnX.Text = "X";
            btnX.UseVisualStyleBackColor = true;
            btnX.Click += btnX_Click;
            // 
            // dataGridFestival
            // 
            dataGridFestival.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridFestival.Location = new Point(33, 86);
            dataGridFestival.Name = "dataGridFestival";
            dataGridFestival.RowHeadersWidth = 51;
            dataGridFestival.RowTemplate.Height = 29;
            dataGridFestival.Size = new Size(626, 270);
            dataGridFestival.TabIndex = 35;
            // 
            // FormFestival
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(32, 30, 45);
            ClientSize = new Size(693, 428);
            Controls.Add(lblChildForm);
            Controls.Add(btnLoad);
            Controls.Add(btnX);
            Controls.Add(dataGridFestival);
            Name = "FormFestival";
            Text = "FormFestival";
            ((System.ComponentModel.ISupportInitialize)dataGridFestival).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblChildForm;
        private Button btnLoad;
        private Button btnX;
        private DataGridView dataGridFestival;
    }
}