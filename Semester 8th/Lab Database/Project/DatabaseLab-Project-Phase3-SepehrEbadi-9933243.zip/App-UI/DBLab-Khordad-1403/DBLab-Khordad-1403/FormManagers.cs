﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DBLab_Khordad_1403
{
    public partial class FormManagers : Form
    {
        string stringConnection = "Data Source=DESKTOP-7NOS0S5\\SQLEXPRESS;Initial Catalog=Database-Lab;Integrated Security=True";

        public FormManagers()
        {
            InitializeComponent();
        }

        private void btnX_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(stringConnection))
            {
                conn.Open();
                SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM Managers", conn);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                dataGridManagers.DataSource = dataTable;
            }
        }
    }
}
