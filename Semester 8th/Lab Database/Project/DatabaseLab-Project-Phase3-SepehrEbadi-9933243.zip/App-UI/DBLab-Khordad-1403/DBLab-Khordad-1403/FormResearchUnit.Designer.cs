﻿namespace DBLab_Khordad_1403
{
    partial class FormResearchUnit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblChildForm = new Label();
            btnLoad = new Button();
            btnX = new Button();
            dataGridResearchUnit = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dataGridResearchUnit).BeginInit();
            SuspendLayout();
            // 
            // lblChildForm
            // 
            lblChildForm.AutoSize = true;
            lblChildForm.FlatStyle = FlatStyle.Flat;
            lblChildForm.Font = new Font("Georgia", 18F, FontStyle.Bold, GraphicsUnit.Point);
            lblChildForm.ForeColor = Color.Gainsboro;
            lblChildForm.Location = new Point(222, 37);
            lblChildForm.Name = "lblChildForm";
            lblChildForm.Size = new Size(235, 35);
            lblChildForm.TabIndex = 46;
            lblChildForm.Text = "Research Unit";
            // 
            // btnLoad
            // 
            btnLoad.FlatStyle = FlatStyle.Flat;
            btnLoad.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            btnLoad.ForeColor = Color.Gainsboro;
            btnLoad.Location = new Point(565, 362);
            btnLoad.Name = "btnLoad";
            btnLoad.Size = new Size(94, 29);
            btnLoad.TabIndex = 45;
            btnLoad.Text = "Load";
            btnLoad.UseVisualStyleBackColor = true;
            btnLoad.Click += btnLoad_Click;
            // 
            // btnX
            // 
            btnX.FlatStyle = FlatStyle.Flat;
            btnX.ForeColor = Color.Gainsboro;
            btnX.Location = new Point(33, 38);
            btnX.Name = "btnX";
            btnX.Size = new Size(94, 29);
            btnX.TabIndex = 44;
            btnX.Text = "X";
            btnX.UseVisualStyleBackColor = true;
            btnX.Click += btnX_Click;
            // 
            // dataGridResearchUnit
            // 
            dataGridResearchUnit.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridResearchUnit.Location = new Point(33, 86);
            dataGridResearchUnit.Name = "dataGridResearchUnit";
            dataGridResearchUnit.RowHeadersWidth = 51;
            dataGridResearchUnit.RowTemplate.Height = 29;
            dataGridResearchUnit.Size = new Size(626, 270);
            dataGridResearchUnit.TabIndex = 43;
            // 
            // FormResearchUnit
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(32, 30, 45);
            ClientSize = new Size(693, 428);
            Controls.Add(lblChildForm);
            Controls.Add(btnLoad);
            Controls.Add(btnX);
            Controls.Add(dataGridResearchUnit);
            Name = "FormResearchUnit";
            Text = "FormResearchUnit";
            ((System.ComponentModel.ISupportInitialize)dataGridResearchUnit).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblChildForm;
        private Button btnLoad;
        private Button btnX;
        private DataGridView dataGridResearchUnit;
    }
}