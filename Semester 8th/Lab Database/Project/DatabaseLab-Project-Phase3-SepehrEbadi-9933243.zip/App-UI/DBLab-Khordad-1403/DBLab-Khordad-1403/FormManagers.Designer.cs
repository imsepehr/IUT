﻿namespace DBLab_Khordad_1403
{
    partial class FormManagers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridManagers = new DataGridView();
            btnX = new Button();
            btnLoad = new Button();
            lblChildForm = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridManagers).BeginInit();
            SuspendLayout();
            // 
            // dataGridManagers
            // 
            dataGridManagers.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridManagers.Location = new Point(12, 63);
            dataGridManagers.Name = "dataGridManagers";
            dataGridManagers.RowHeadersWidth = 51;
            dataGridManagers.RowTemplate.Height = 29;
            dataGridManagers.Size = new Size(669, 270);
            dataGridManagers.TabIndex = 0;
            // 
            // btnX
            // 
            btnX.FlatStyle = FlatStyle.Flat;
            btnX.ForeColor = Color.Gainsboro;
            btnX.Location = new Point(12, 12);
            btnX.Name = "btnX";
            btnX.Size = new Size(94, 29);
            btnX.TabIndex = 1;
            btnX.Text = "X";
            btnX.UseVisualStyleBackColor = true;
            btnX.Click += btnX_Click;
            // 
            // btnLoad
            // 
            btnLoad.FlatStyle = FlatStyle.Flat;
            btnLoad.Font = new Font("Georgia", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            btnLoad.ForeColor = Color.Gainsboro;
            btnLoad.Location = new Point(579, 367);
            btnLoad.Name = "btnLoad";
            btnLoad.Size = new Size(94, 29);
            btnLoad.TabIndex = 2;
            btnLoad.Text = "Load ";
            btnLoad.UseVisualStyleBackColor = true;
            btnLoad.Click += button2_Click;
            // 
            // lblChildForm
            // 
            lblChildForm.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            lblChildForm.AutoSize = true;
            lblChildForm.Font = new Font("Georgia", 16.2F, FontStyle.Bold, GraphicsUnit.Point);
            lblChildForm.ForeColor = Color.Gainsboro;
            lblChildForm.Location = new Point(283, 17);
            lblChildForm.Name = "lblChildForm";
            lblChildForm.Size = new Size(157, 32);
            lblChildForm.TabIndex = 3;
            lblChildForm.Text = "Managers";
            // 
            // FormManagers
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(32, 30, 45);
            ClientSize = new Size(693, 428);
            Controls.Add(lblChildForm);
            Controls.Add(btnLoad);
            Controls.Add(btnX);
            Controls.Add(dataGridManagers);
            Name = "FormManagers";
            Text = "Managers";
            ((System.ComponentModel.ISupportInitialize)dataGridManagers).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridManagers;
        private Button btnX;
        private Button btnLoad;
        private Label lblChildForm;
    }
}