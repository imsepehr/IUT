namespace DBLab_Khordad_1403
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            customizeDesign();
        }
        private void customizeDesign()
        {
            panelManageSubmenu.Visible = false;
            panelCompanySubmenu.Visible = false;
            panelUnitSubmenu.Visible = false;
            panelViewsSubmenu.Visible = false;
        }

        private void hideSubmenu()
        {
            if (panelManageSubmenu.Visible == true)
                panelManageSubmenu.Visible = false;
            if (panelCompanySubmenu.Visible == true)
                panelCompanySubmenu.Visible = false;
            if (panelUnitSubmenu.Visible == true)
                panelUnitSubmenu.Visible = false;
            if (panelViewsSubmenu.Visible == true)
                panelViewsSubmenu.Visible = false;
        }

        private void showSubmenu(Panel subMenu)
        {
            if (subMenu.Visible == false)
            {
                hideSubmenu();
                subMenu.Visible = true;
            }
            else
                subMenu.Visible = false;
        }

        private void btnManage_Click(object sender, EventArgs e)
        {
            showSubmenu(panelManageSubmenu);
        }

        private void btnManagers_Click(object sender, EventArgs e)
        {
            openChildForm(new FormManagers());
            //codes
            hideSubmenu();
        }

        private void btnExhibitionsParticipate_Click(object sender, EventArgs e)
        {
            openChildForm(new FormExhibitionParticipate());
            //codes
            hideSubmenu();
        }

        private void btnFestivalsParticipate_Click(object sender, EventArgs e)
        {
            openChildForm(new FormFestivalParticipate());
            //codes
            hideSubmenu();
        }

        private void btnVisitsParticipate_Click(object sender, EventArgs e)
        {
            openChildForm(new FormVisitParticipate());
            //codes
            hideSubmenu();
        }

        private void btnLoanTaken_Click(object sender, EventArgs e)
        {
            openChildForm(new FormLoanTaken());
            //codes
            hideSubmenu();
        }

        private void btnIndustrialPartner_Click(object sender, EventArgs e)
        {
            openChildForm(new FormIndustrialPartner());
            //codes
            hideSubmenu();
        }

        private void btnCompany_Click(object sender, EventArgs e)
        {
            showSubmenu(panelCompanySubmenu);
        }

        private void btnCompanies_Click(object sender, EventArgs e)
        {
            openChildForm(new FormCompanies());
            //codes
            hideSubmenu();
        }

        private void btnCompaniesPartner_Click(object sender, EventArgs e)
        {
            openChildForm(new FormCompanyPartner());
            //codes
            hideSubmenu();
        }

        private void btnUnit_Click(object sender, EventArgs e)
        {
            showSubmenu(panelUnitSubmenu);
        }

        private void btnResearchUnits_Click(object sender, EventArgs e)
        {
            openChildForm(new FormResearchUnit());
            //codes
            hideSubmenu();
        }

        private void btnEquipmentFacilities_Click(object sender, EventArgs e)
        {
            openChildForm(new FormEquipmentFacility());
            //codes
            hideSubmenu();
        }

        private void btnEmployee_Click(object sender, EventArgs e)
        {
            openChildForm(new FormEmployee());
            //codes
            hideSubmenu();
        }

        private void btnExhibition_Click(object sender, EventArgs e)
        {
            openChildForm(new FormExhibition());
            //codes
            hideSubmenu();
        }

        private void btnFestival_Click(object sender, EventArgs e)
        {
            openChildForm(new FormFestival());
            //codes
            hideSubmenu();
        }

        private void btnInternationalVisit_Click(object sender, EventArgs e)
        {
            openChildForm(new FormInternationalVisit());
            //codes
            hideSubmenu();
        }

        private void btnFacility_Click(object sender, EventArgs e)
        {
            openChildForm(new FormFacility());
            //codes
            hideSubmenu();
        }

        private Form activeForm = null;
        private void openChildForm(Form childForm)
        {
            if (activeForm != null)
                activeForm.Close();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panelChildForm.Controls.Add(childForm);
            panelChildForm.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }

        private void btnViews_Click(object sender, EventArgs e)
        {
            showSubmenu(panelViewsSubmenu);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblTime.Text = DateTime.Now.ToLongTimeString();
            lblDate.Text = DateTime.Now.ToLongDateString();
        }

        private void btnAbout_Click(object sender, EventArgs e)
        {
            openChildForm(new FormAbout());
            //codes
            hideSubmenu();
        }

        private void btnEmpOfCompany_Click(object sender, EventArgs e)
        {
            openChildForm(new FormViewEmpOfCompany());
            //codes
            hideSubmenu();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openChildForm(new FormViewAvgOfCompanies());
            //codes
            hideSubmenu();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            openChildForm(new FormViewHighSalary());
            //codes
            hideSubmenu();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            hideSubmenu();  
        }
    }
}