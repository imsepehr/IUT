﻿namespace DBLab_Khordad_1403
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            panelSideMenu = new Panel();
            panelViewsSubmenu = new Panel();
            button3 = new Button();
            button1 = new Button();
            btnEmpOfCompany = new Button();
            btnAbout = new Button();
            btnExit = new Button();
            btnViews = new Button();
            btnFacility = new Button();
            panelUnitSubmenu = new Panel();
            btnEquipmentFacilities = new Button();
            btnResearchUnits = new Button();
            btnUnit = new Button();
            btnInternationalVisit = new Button();
            btnFestival = new Button();
            btnExhibition = new Button();
            btnEmployee = new Button();
            panelCompanySubmenu = new Panel();
            btnCompaniesPartner = new Button();
            btnCompanies = new Button();
            btnCompany = new Button();
            panelManageSubmenu = new Panel();
            btnIndustrialPartner = new Button();
            btnLoanTaken = new Button();
            btnVisitsParticipate = new Button();
            btnFestivalsParticipate = new Button();
            btnExhibitionsParticipate = new Button();
            btnManagers = new Button();
            btnManage = new Button();
            panelLogo = new Panel();
            pictureBox2 = new PictureBox();
            panelFooter = new Panel();
            lblDate = new Label();
            lblTime = new Label();
            panelChildForm = new Panel();
            pictureBox1 = new PictureBox();
            timer1 = new System.Windows.Forms.Timer(components);
            panelSideMenu.SuspendLayout();
            panelViewsSubmenu.SuspendLayout();
            panelUnitSubmenu.SuspendLayout();
            panelCompanySubmenu.SuspendLayout();
            panelManageSubmenu.SuspendLayout();
            panelLogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panelFooter.SuspendLayout();
            panelChildForm.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panelSideMenu
            // 
            panelSideMenu.AutoScroll = true;
            panelSideMenu.BackColor = Color.FromArgb(11, 7, 17);
            panelSideMenu.Controls.Add(panelViewsSubmenu);
            panelSideMenu.Controls.Add(btnAbout);
            panelSideMenu.Controls.Add(btnExit);
            panelSideMenu.Controls.Add(btnViews);
            panelSideMenu.Controls.Add(btnFacility);
            panelSideMenu.Controls.Add(panelUnitSubmenu);
            panelSideMenu.Controls.Add(btnUnit);
            panelSideMenu.Controls.Add(btnInternationalVisit);
            panelSideMenu.Controls.Add(btnFestival);
            panelSideMenu.Controls.Add(btnExhibition);
            panelSideMenu.Controls.Add(btnEmployee);
            panelSideMenu.Controls.Add(panelCompanySubmenu);
            panelSideMenu.Controls.Add(btnCompany);
            panelSideMenu.Controls.Add(panelManageSubmenu);
            panelSideMenu.Controls.Add(btnManage);
            panelSideMenu.Controls.Add(panelLogo);
            panelSideMenu.Dock = DockStyle.Left;
            panelSideMenu.Location = new Point(0, 0);
            panelSideMenu.Name = "panelSideMenu";
            panelSideMenu.Size = new Size(239, 703);
            panelSideMenu.TabIndex = 0;
            // 
            // panelViewsSubmenu
            // 
            panelViewsSubmenu.BackColor = Color.FromArgb(35, 32, 39);
            panelViewsSubmenu.Controls.Add(button3);
            panelViewsSubmenu.Controls.Add(button1);
            panelViewsSubmenu.Controls.Add(btnEmpOfCompany);
            panelViewsSubmenu.Dock = DockStyle.Top;
            panelViewsSubmenu.Location = new Point(0, 970);
            panelViewsSubmenu.Name = "panelViewsSubmenu";
            panelViewsSubmenu.Size = new Size(218, 134);
            panelViewsSubmenu.TabIndex = 15;
            // 
            // button3
            // 
            button3.Dock = DockStyle.Top;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Segoe UI", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            button3.ForeColor = Color.LightGray;
            button3.Location = new Point(0, 80);
            button3.Name = "button3";
            button3.Padding = new Padding(35, 0, 0, 0);
            button3.Size = new Size(218, 40);
            button3.TabIndex = 2;
            button3.Text = "High Earning Employee\r\n";
            button3.TextAlign = ContentAlignment.MiddleLeft;
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button1
            // 
            button1.Dock = DockStyle.Top;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            button1.ForeColor = Color.LightGray;
            button1.Location = new Point(0, 40);
            button1.Name = "button1";
            button1.Padding = new Padding(35, 0, 0, 0);
            button1.Size = new Size(218, 40);
            button1.TabIndex = 1;
            button1.Text = "Avg Salary of Companies";
            button1.TextAlign = ContentAlignment.MiddleLeft;
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // btnEmpOfCompany
            // 
            btnEmpOfCompany.Dock = DockStyle.Top;
            btnEmpOfCompany.FlatAppearance.BorderSize = 0;
            btnEmpOfCompany.FlatStyle = FlatStyle.Flat;
            btnEmpOfCompany.Font = new Font("Segoe UI", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            btnEmpOfCompany.ForeColor = Color.LightGray;
            btnEmpOfCompany.Location = new Point(0, 0);
            btnEmpOfCompany.Name = "btnEmpOfCompany";
            btnEmpOfCompany.Padding = new Padding(35, 0, 0, 0);
            btnEmpOfCompany.Size = new Size(218, 40);
            btnEmpOfCompany.TabIndex = 0;
            btnEmpOfCompany.Text = "Employees of Companies";
            btnEmpOfCompany.TextAlign = ContentAlignment.MiddleLeft;
            btnEmpOfCompany.UseVisualStyleBackColor = true;
            btnEmpOfCompany.Click += btnEmpOfCompany_Click;
            // 
            // btnAbout
            // 
            btnAbout.Dock = DockStyle.Bottom;
            btnAbout.FlatAppearance.BorderSize = 0;
            btnAbout.FlatStyle = FlatStyle.Flat;
            btnAbout.ForeColor = Color.Gainsboro;
            btnAbout.Location = new Point(0, 1104);
            btnAbout.Name = "btnAbout";
            btnAbout.Padding = new Padding(10, 0, 0, 0);
            btnAbout.Size = new Size(218, 45);
            btnAbout.TabIndex = 14;
            btnAbout.Text = "About Project";
            btnAbout.TextAlign = ContentAlignment.MiddleLeft;
            btnAbout.UseVisualStyleBackColor = true;
            btnAbout.Click += btnAbout_Click;
            // 
            // btnExit
            // 
            btnExit.Dock = DockStyle.Bottom;
            btnExit.FlatAppearance.BorderSize = 0;
            btnExit.FlatStyle = FlatStyle.Flat;
            btnExit.ForeColor = Color.Gainsboro;
            btnExit.Location = new Point(0, 1149);
            btnExit.Name = "btnExit";
            btnExit.Padding = new Padding(10, 0, 0, 0);
            btnExit.Size = new Size(218, 45);
            btnExit.TabIndex = 13;
            btnExit.Text = "EXIT";
            btnExit.TextAlign = ContentAlignment.MiddleLeft;
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += btnExit_Click;
            // 
            // btnViews
            // 
            btnViews.Dock = DockStyle.Top;
            btnViews.FlatAppearance.BorderSize = 0;
            btnViews.FlatStyle = FlatStyle.Flat;
            btnViews.ForeColor = Color.Gainsboro;
            btnViews.Location = new Point(0, 925);
            btnViews.Name = "btnViews";
            btnViews.Padding = new Padding(10, 0, 0, 0);
            btnViews.Size = new Size(218, 45);
            btnViews.TabIndex = 12;
            btnViews.Text = "Views >";
            btnViews.TextAlign = ContentAlignment.MiddleLeft;
            btnViews.UseVisualStyleBackColor = true;
            btnViews.Click += btnViews_Click;
            // 
            // btnFacility
            // 
            btnFacility.Dock = DockStyle.Top;
            btnFacility.FlatAppearance.BorderSize = 0;
            btnFacility.FlatStyle = FlatStyle.Flat;
            btnFacility.ForeColor = Color.Gainsboro;
            btnFacility.Location = new Point(0, 880);
            btnFacility.Name = "btnFacility";
            btnFacility.Padding = new Padding(10, 0, 0, 0);
            btnFacility.Size = new Size(218, 45);
            btnFacility.TabIndex = 11;
            btnFacility.Text = "Facility";
            btnFacility.TextAlign = ContentAlignment.MiddleLeft;
            btnFacility.UseVisualStyleBackColor = true;
            btnFacility.Click += btnFacility_Click;
            // 
            // panelUnitSubmenu
            // 
            panelUnitSubmenu.BackColor = Color.FromArgb(35, 32, 39);
            panelUnitSubmenu.Controls.Add(btnEquipmentFacilities);
            panelUnitSubmenu.Controls.Add(btnResearchUnits);
            panelUnitSubmenu.Dock = DockStyle.Top;
            panelUnitSubmenu.Location = new Point(0, 785);
            panelUnitSubmenu.Name = "panelUnitSubmenu";
            panelUnitSubmenu.Size = new Size(218, 95);
            panelUnitSubmenu.TabIndex = 10;
            // 
            // btnEquipmentFacilities
            // 
            btnEquipmentFacilities.Dock = DockStyle.Top;
            btnEquipmentFacilities.FlatAppearance.BorderSize = 0;
            btnEquipmentFacilities.FlatStyle = FlatStyle.Flat;
            btnEquipmentFacilities.ForeColor = Color.LightGray;
            btnEquipmentFacilities.Location = new Point(0, 40);
            btnEquipmentFacilities.Name = "btnEquipmentFacilities";
            btnEquipmentFacilities.Padding = new Padding(35, 0, 0, 0);
            btnEquipmentFacilities.Size = new Size(218, 40);
            btnEquipmentFacilities.TabIndex = 1;
            btnEquipmentFacilities.Text = "Equipment Facilities";
            btnEquipmentFacilities.TextAlign = ContentAlignment.MiddleLeft;
            btnEquipmentFacilities.UseVisualStyleBackColor = true;
            btnEquipmentFacilities.Click += btnEquipmentFacilities_Click;
            // 
            // btnResearchUnits
            // 
            btnResearchUnits.Dock = DockStyle.Top;
            btnResearchUnits.FlatAppearance.BorderSize = 0;
            btnResearchUnits.FlatStyle = FlatStyle.Flat;
            btnResearchUnits.ForeColor = Color.LightGray;
            btnResearchUnits.Location = new Point(0, 0);
            btnResearchUnits.Name = "btnResearchUnits";
            btnResearchUnits.Padding = new Padding(35, 0, 0, 0);
            btnResearchUnits.Size = new Size(218, 40);
            btnResearchUnits.TabIndex = 0;
            btnResearchUnits.Text = "Research Units";
            btnResearchUnits.TextAlign = ContentAlignment.MiddleLeft;
            btnResearchUnits.UseVisualStyleBackColor = true;
            btnResearchUnits.Click += btnResearchUnits_Click;
            // 
            // btnUnit
            // 
            btnUnit.Dock = DockStyle.Top;
            btnUnit.FlatAppearance.BorderSize = 0;
            btnUnit.FlatStyle = FlatStyle.Flat;
            btnUnit.ForeColor = Color.Gainsboro;
            btnUnit.Location = new Point(0, 740);
            btnUnit.Name = "btnUnit";
            btnUnit.Padding = new Padding(10, 0, 0, 0);
            btnUnit.Size = new Size(218, 45);
            btnUnit.TabIndex = 9;
            btnUnit.Text = "Unit >";
            btnUnit.TextAlign = ContentAlignment.MiddleLeft;
            btnUnit.UseVisualStyleBackColor = true;
            btnUnit.Click += btnUnit_Click;
            // 
            // btnInternationalVisit
            // 
            btnInternationalVisit.Dock = DockStyle.Top;
            btnInternationalVisit.FlatAppearance.BorderSize = 0;
            btnInternationalVisit.FlatStyle = FlatStyle.Flat;
            btnInternationalVisit.ForeColor = Color.Gainsboro;
            btnInternationalVisit.Location = new Point(0, 695);
            btnInternationalVisit.Name = "btnInternationalVisit";
            btnInternationalVisit.Padding = new Padding(10, 0, 0, 0);
            btnInternationalVisit.Size = new Size(218, 45);
            btnInternationalVisit.TabIndex = 8;
            btnInternationalVisit.Text = "International Visit";
            btnInternationalVisit.TextAlign = ContentAlignment.MiddleLeft;
            btnInternationalVisit.UseVisualStyleBackColor = true;
            btnInternationalVisit.Click += btnInternationalVisit_Click;
            // 
            // btnFestival
            // 
            btnFestival.Dock = DockStyle.Top;
            btnFestival.FlatAppearance.BorderSize = 0;
            btnFestival.FlatStyle = FlatStyle.Flat;
            btnFestival.ForeColor = Color.Gainsboro;
            btnFestival.Location = new Point(0, 650);
            btnFestival.Name = "btnFestival";
            btnFestival.Padding = new Padding(10, 0, 0, 0);
            btnFestival.Size = new Size(218, 45);
            btnFestival.TabIndex = 7;
            btnFestival.Text = "Festival";
            btnFestival.TextAlign = ContentAlignment.MiddleLeft;
            btnFestival.UseVisualStyleBackColor = true;
            btnFestival.Click += btnFestival_Click;
            // 
            // btnExhibition
            // 
            btnExhibition.Dock = DockStyle.Top;
            btnExhibition.FlatAppearance.BorderSize = 0;
            btnExhibition.FlatStyle = FlatStyle.Flat;
            btnExhibition.ForeColor = Color.Gainsboro;
            btnExhibition.Location = new Point(0, 605);
            btnExhibition.Name = "btnExhibition";
            btnExhibition.Padding = new Padding(10, 0, 0, 0);
            btnExhibition.Size = new Size(218, 45);
            btnExhibition.TabIndex = 6;
            btnExhibition.Text = "Exhibition";
            btnExhibition.TextAlign = ContentAlignment.MiddleLeft;
            btnExhibition.UseVisualStyleBackColor = true;
            btnExhibition.Click += btnExhibition_Click;
            // 
            // btnEmployee
            // 
            btnEmployee.Dock = DockStyle.Top;
            btnEmployee.FlatAppearance.BorderSize = 0;
            btnEmployee.FlatStyle = FlatStyle.Flat;
            btnEmployee.ForeColor = Color.Gainsboro;
            btnEmployee.Location = new Point(0, 560);
            btnEmployee.Name = "btnEmployee";
            btnEmployee.Padding = new Padding(10, 0, 0, 0);
            btnEmployee.Size = new Size(218, 45);
            btnEmployee.TabIndex = 5;
            btnEmployee.Text = "Employee";
            btnEmployee.TextAlign = ContentAlignment.MiddleLeft;
            btnEmployee.UseVisualStyleBackColor = true;
            btnEmployee.Click += btnEmployee_Click;
            // 
            // panelCompanySubmenu
            // 
            panelCompanySubmenu.BackColor = Color.FromArgb(35, 32, 39);
            panelCompanySubmenu.Controls.Add(btnCompaniesPartner);
            panelCompanySubmenu.Controls.Add(btnCompanies);
            panelCompanySubmenu.Dock = DockStyle.Top;
            panelCompanySubmenu.Location = new Point(0, 465);
            panelCompanySubmenu.Name = "panelCompanySubmenu";
            panelCompanySubmenu.Size = new Size(218, 95);
            panelCompanySubmenu.TabIndex = 4;
            // 
            // btnCompaniesPartner
            // 
            btnCompaniesPartner.Dock = DockStyle.Top;
            btnCompaniesPartner.FlatAppearance.BorderSize = 0;
            btnCompaniesPartner.FlatStyle = FlatStyle.Flat;
            btnCompaniesPartner.ForeColor = Color.LightGray;
            btnCompaniesPartner.Location = new Point(0, 40);
            btnCompaniesPartner.Name = "btnCompaniesPartner";
            btnCompaniesPartner.Padding = new Padding(35, 0, 0, 0);
            btnCompaniesPartner.Size = new Size(218, 40);
            btnCompaniesPartner.TabIndex = 1;
            btnCompaniesPartner.Text = "Companies Partner";
            btnCompaniesPartner.TextAlign = ContentAlignment.MiddleLeft;
            btnCompaniesPartner.UseVisualStyleBackColor = true;
            btnCompaniesPartner.Click += btnCompaniesPartner_Click;
            // 
            // btnCompanies
            // 
            btnCompanies.Dock = DockStyle.Top;
            btnCompanies.FlatAppearance.BorderSize = 0;
            btnCompanies.FlatStyle = FlatStyle.Flat;
            btnCompanies.ForeColor = Color.LightGray;
            btnCompanies.Location = new Point(0, 0);
            btnCompanies.Name = "btnCompanies";
            btnCompanies.Padding = new Padding(35, 0, 0, 0);
            btnCompanies.Size = new Size(218, 40);
            btnCompanies.TabIndex = 0;
            btnCompanies.Text = "Companies";
            btnCompanies.TextAlign = ContentAlignment.MiddleLeft;
            btnCompanies.UseVisualStyleBackColor = true;
            btnCompanies.Click += btnCompanies_Click;
            // 
            // btnCompany
            // 
            btnCompany.Dock = DockStyle.Top;
            btnCompany.FlatAppearance.BorderSize = 0;
            btnCompany.FlatStyle = FlatStyle.Flat;
            btnCompany.ForeColor = Color.Gainsboro;
            btnCompany.Location = new Point(0, 420);
            btnCompany.Name = "btnCompany";
            btnCompany.Padding = new Padding(10, 0, 0, 0);
            btnCompany.Size = new Size(218, 45);
            btnCompany.TabIndex = 3;
            btnCompany.Text = "Company >";
            btnCompany.TextAlign = ContentAlignment.MiddleLeft;
            btnCompany.UseVisualStyleBackColor = true;
            btnCompany.Click += btnCompany_Click;
            // 
            // panelManageSubmenu
            // 
            panelManageSubmenu.BackColor = Color.FromArgb(35, 32, 39);
            panelManageSubmenu.Controls.Add(btnIndustrialPartner);
            panelManageSubmenu.Controls.Add(btnLoanTaken);
            panelManageSubmenu.Controls.Add(btnVisitsParticipate);
            panelManageSubmenu.Controls.Add(btnFestivalsParticipate);
            panelManageSubmenu.Controls.Add(btnExhibitionsParticipate);
            panelManageSubmenu.Controls.Add(btnManagers);
            panelManageSubmenu.Dock = DockStyle.Top;
            panelManageSubmenu.Location = new Point(0, 162);
            panelManageSubmenu.Name = "panelManageSubmenu";
            panelManageSubmenu.Size = new Size(218, 258);
            panelManageSubmenu.TabIndex = 2;
            // 
            // btnIndustrialPartner
            // 
            btnIndustrialPartner.Dock = DockStyle.Top;
            btnIndustrialPartner.FlatAppearance.BorderSize = 0;
            btnIndustrialPartner.FlatStyle = FlatStyle.Flat;
            btnIndustrialPartner.ForeColor = Color.LightGray;
            btnIndustrialPartner.Location = new Point(0, 200);
            btnIndustrialPartner.Name = "btnIndustrialPartner";
            btnIndustrialPartner.Padding = new Padding(35, 0, 0, 0);
            btnIndustrialPartner.Size = new Size(218, 40);
            btnIndustrialPartner.TabIndex = 5;
            btnIndustrialPartner.Text = "Industrial Partner";
            btnIndustrialPartner.TextAlign = ContentAlignment.MiddleLeft;
            btnIndustrialPartner.UseVisualStyleBackColor = true;
            btnIndustrialPartner.Click += btnIndustrialPartner_Click;
            // 
            // btnLoanTaken
            // 
            btnLoanTaken.Dock = DockStyle.Top;
            btnLoanTaken.FlatAppearance.BorderSize = 0;
            btnLoanTaken.FlatStyle = FlatStyle.Flat;
            btnLoanTaken.ForeColor = Color.LightGray;
            btnLoanTaken.Location = new Point(0, 160);
            btnLoanTaken.Name = "btnLoanTaken";
            btnLoanTaken.Padding = new Padding(35, 0, 0, 0);
            btnLoanTaken.Size = new Size(218, 40);
            btnLoanTaken.TabIndex = 4;
            btnLoanTaken.Text = "Loan Taken";
            btnLoanTaken.TextAlign = ContentAlignment.MiddleLeft;
            btnLoanTaken.UseVisualStyleBackColor = true;
            btnLoanTaken.Click += btnLoanTaken_Click;
            // 
            // btnVisitsParticipate
            // 
            btnVisitsParticipate.Dock = DockStyle.Top;
            btnVisitsParticipate.FlatAppearance.BorderSize = 0;
            btnVisitsParticipate.FlatStyle = FlatStyle.Flat;
            btnVisitsParticipate.ForeColor = Color.LightGray;
            btnVisitsParticipate.Location = new Point(0, 120);
            btnVisitsParticipate.Name = "btnVisitsParticipate";
            btnVisitsParticipate.Padding = new Padding(35, 0, 0, 0);
            btnVisitsParticipate.Size = new Size(218, 40);
            btnVisitsParticipate.TabIndex = 3;
            btnVisitsParticipate.Text = "Visits Participate";
            btnVisitsParticipate.TextAlign = ContentAlignment.MiddleLeft;
            btnVisitsParticipate.UseVisualStyleBackColor = true;
            btnVisitsParticipate.Click += btnVisitsParticipate_Click;
            // 
            // btnFestivalsParticipate
            // 
            btnFestivalsParticipate.Dock = DockStyle.Top;
            btnFestivalsParticipate.FlatAppearance.BorderSize = 0;
            btnFestivalsParticipate.FlatStyle = FlatStyle.Flat;
            btnFestivalsParticipate.ForeColor = Color.LightGray;
            btnFestivalsParticipate.Location = new Point(0, 80);
            btnFestivalsParticipate.Name = "btnFestivalsParticipate";
            btnFestivalsParticipate.Padding = new Padding(35, 0, 0, 0);
            btnFestivalsParticipate.Size = new Size(218, 40);
            btnFestivalsParticipate.TabIndex = 2;
            btnFestivalsParticipate.Text = "Festivals Participate";
            btnFestivalsParticipate.TextAlign = ContentAlignment.MiddleLeft;
            btnFestivalsParticipate.UseVisualStyleBackColor = true;
            btnFestivalsParticipate.Click += btnFestivalsParticipate_Click;
            // 
            // btnExhibitionsParticipate
            // 
            btnExhibitionsParticipate.Dock = DockStyle.Top;
            btnExhibitionsParticipate.FlatAppearance.BorderSize = 0;
            btnExhibitionsParticipate.FlatStyle = FlatStyle.Flat;
            btnExhibitionsParticipate.ForeColor = Color.LightGray;
            btnExhibitionsParticipate.Location = new Point(0, 40);
            btnExhibitionsParticipate.Name = "btnExhibitionsParticipate";
            btnExhibitionsParticipate.Padding = new Padding(35, 0, 0, 0);
            btnExhibitionsParticipate.Size = new Size(218, 40);
            btnExhibitionsParticipate.TabIndex = 1;
            btnExhibitionsParticipate.Text = "Exhibitions Participate";
            btnExhibitionsParticipate.TextAlign = ContentAlignment.MiddleLeft;
            btnExhibitionsParticipate.UseVisualStyleBackColor = true;
            btnExhibitionsParticipate.Click += btnExhibitionsParticipate_Click;
            // 
            // btnManagers
            // 
            btnManagers.Dock = DockStyle.Top;
            btnManagers.FlatAppearance.BorderSize = 0;
            btnManagers.FlatStyle = FlatStyle.Flat;
            btnManagers.ForeColor = Color.LightGray;
            btnManagers.Location = new Point(0, 0);
            btnManagers.Name = "btnManagers";
            btnManagers.Padding = new Padding(35, 0, 0, 0);
            btnManagers.Size = new Size(218, 40);
            btnManagers.TabIndex = 0;
            btnManagers.Text = "Managers";
            btnManagers.TextAlign = ContentAlignment.MiddleLeft;
            btnManagers.UseVisualStyleBackColor = true;
            btnManagers.Click += btnManagers_Click;
            // 
            // btnManage
            // 
            btnManage.Dock = DockStyle.Top;
            btnManage.FlatAppearance.BorderSize = 0;
            btnManage.FlatStyle = FlatStyle.Flat;
            btnManage.ForeColor = Color.Gainsboro;
            btnManage.Location = new Point(0, 117);
            btnManage.Name = "btnManage";
            btnManage.Padding = new Padding(10, 0, 0, 0);
            btnManage.Size = new Size(218, 45);
            btnManage.TabIndex = 1;
            btnManage.Text = "Manage >";
            btnManage.TextAlign = ContentAlignment.MiddleLeft;
            btnManage.UseVisualStyleBackColor = true;
            btnManage.Click += btnManage_Click;
            // 
            // panelLogo
            // 
            panelLogo.Controls.Add(pictureBox2);
            panelLogo.Dock = DockStyle.Top;
            panelLogo.Location = new Point(0, 0);
            panelLogo.Name = "panelLogo";
            panelLogo.Size = new Size(218, 117);
            panelLogo.TabIndex = 0;
            // 
            // pictureBox2
            // 
            pictureBox2.Dock = DockStyle.Fill;
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(0, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(218, 117);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 0;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // panelFooter
            // 
            panelFooter.BackColor = Color.FromArgb(23, 21, 32);
            panelFooter.Controls.Add(lblDate);
            panelFooter.Controls.Add(lblTime);
            panelFooter.Dock = DockStyle.Bottom;
            panelFooter.Location = new Point(239, 578);
            panelFooter.Name = "panelFooter";
            panelFooter.Size = new Size(693, 125);
            panelFooter.TabIndex = 1;
            // 
            // lblDate
            // 
            lblDate.AutoSize = true;
            lblDate.Font = new Font("Impact", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            lblDate.ForeColor = Color.Gainsboro;
            lblDate.Location = new Point(453, 11);
            lblDate.Name = "lblDate";
            lblDate.Size = new Size(43, 22);
            lblDate.TabIndex = 1;
            lblDate.Text = "Date";
            // 
            // lblTime
            // 
            lblTime.AutoSize = true;
            lblTime.Font = new Font("Impact", 12F, FontStyle.Regular, GraphicsUnit.Point);
            lblTime.ForeColor = Color.Gainsboro;
            lblTime.Location = new Point(30, 8);
            lblTime.Name = "lblTime";
            lblTime.Size = new Size(51, 25);
            lblTime.TabIndex = 0;
            lblTime.Text = "Time";
            // 
            // panelChildForm
            // 
            panelChildForm.BackColor = Color.FromArgb(32, 30, 45);
            panelChildForm.Controls.Add(pictureBox1);
            panelChildForm.Dock = DockStyle.Fill;
            panelChildForm.Location = new Point(239, 0);
            panelChildForm.Name = "panelChildForm";
            panelChildForm.Size = new Size(693, 578);
            panelChildForm.TabIndex = 2;
            // 
            // pictureBox1
            // 
            pictureBox1.Anchor = AnchorStyles.None;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(244, 214);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(252, 184);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // timer1
            // 
            timer1.Enabled = true;
            timer1.Tick += timer1_Tick;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(932, 703);
            Controls.Add(panelChildForm);
            Controls.Add(panelFooter);
            Controls.Add(panelSideMenu);
            MinimumSize = new Size(950, 600);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            panelSideMenu.ResumeLayout(false);
            panelViewsSubmenu.ResumeLayout(false);
            panelUnitSubmenu.ResumeLayout(false);
            panelCompanySubmenu.ResumeLayout(false);
            panelManageSubmenu.ResumeLayout(false);
            panelLogo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panelFooter.ResumeLayout(false);
            panelFooter.PerformLayout();
            panelChildForm.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panelSideMenu;
        private Panel panelManageSubmenu;
        private Button btnManagers;
        private Button btnManage;
        private Panel panelLogo;
        private Button btnIndustrialPartner;
        private Button btnLoanTaken;
        private Button btnVisitsParticipate;
        private Button btnFestivalsParticipate;
        private Button btnExhibitionsParticipate;
        private Button btnFacility;
        private Panel panelUnitSubmenu;
        private Button btnEquipmentFacilities;
        private Button btnResearchUnits;
        private Button btnUnit;
        private Button btnInternationalVisit;
        private Button btnFestival;
        private Button btnExhibition;
        private Button btnEmployee;
        private Panel panelCompanySubmenu;
        private Button btnCompaniesPartner;
        private Button btnCompanies;
        private Button btnCompany;
        private Panel panelFooter;
        private Panel panelChildForm;
        private PictureBox pictureBox1;
        private Button btnViews;
        private Button btnAbout;
        private Button btnExit;
        private Label lblDate;
        private Label lblTime;
        private System.Windows.Forms.Timer timer1;
        private PictureBox pictureBox2;
        private Panel panelViewsSubmenu;
        private Button button3;
        private Button button1;
        private Button btnEmpOfCompany;
    }
}