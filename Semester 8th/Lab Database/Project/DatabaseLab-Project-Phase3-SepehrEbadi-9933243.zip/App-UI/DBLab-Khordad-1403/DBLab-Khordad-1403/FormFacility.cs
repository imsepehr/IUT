﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBLab_Khordad_1403
{
    public partial class FormFacility : Form
    {
        string stringConnection = "Data Source=DESKTOP-7NOS0S5\\SQLEXPRESS;Initial Catalog=Database-Lab;Integrated Security=True";

        public FormFacility()
        {
            InitializeComponent();
        }

        private void btnX_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(stringConnection))
            {
                conn.Open();
                SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM Facilities", conn);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                dataGridFacility.DataSource = dataTable;
            }
        }
    }
}
