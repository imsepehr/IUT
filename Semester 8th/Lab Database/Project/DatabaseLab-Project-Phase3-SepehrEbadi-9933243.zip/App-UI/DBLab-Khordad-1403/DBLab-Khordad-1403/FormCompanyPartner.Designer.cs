﻿namespace DBLab_Khordad_1403
{
    partial class FormCompanyPartner
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblChildForm = new Label();
            btnLoad = new Button();
            btnX = new Button();
            dataGridCompanyPartner = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dataGridCompanyPartner).BeginInit();
            SuspendLayout();
            // 
            // lblChildForm
            // 
            lblChildForm.AutoSize = true;
            lblChildForm.FlatStyle = FlatStyle.Flat;
            lblChildForm.Font = new Font("Georgia", 18F, FontStyle.Bold, GraphicsUnit.Point);
            lblChildForm.ForeColor = Color.Gainsboro;
            lblChildForm.Location = new Point(206, 35);
            lblChildForm.Name = "lblChildForm";
            lblChildForm.Size = new Size(305, 35);
            lblChildForm.TabIndex = 30;
            lblChildForm.Text = "Company Partners";
            // 
            // btnLoad
            // 
            btnLoad.FlatStyle = FlatStyle.Flat;
            btnLoad.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            btnLoad.ForeColor = Color.Gainsboro;
            btnLoad.Location = new Point(537, 327);
            btnLoad.Name = "btnLoad";
            btnLoad.Size = new Size(94, 29);
            btnLoad.TabIndex = 29;
            btnLoad.Text = "Load";
            btnLoad.UseVisualStyleBackColor = true;
            btnLoad.Click += btnLoad_Click;
            // 
            // btnX
            // 
            btnX.FlatStyle = FlatStyle.Flat;
            btnX.ForeColor = Color.Gainsboro;
            btnX.Location = new Point(33, 38);
            btnX.Name = "btnX";
            btnX.Size = new Size(94, 29);
            btnX.TabIndex = 28;
            btnX.Text = "X";
            btnX.UseVisualStyleBackColor = true;
            btnX.Click += btnX_Click;
            // 
            // dataGridCompanyPartner
            // 
            dataGridCompanyPartner.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridCompanyPartner.Location = new Point(141, 86);
            dataGridCompanyPartner.Name = "dataGridCompanyPartner";
            dataGridCompanyPartner.RowHeadersWidth = 51;
            dataGridCompanyPartner.RowTemplate.Height = 29;
            dataGridCompanyPartner.Size = new Size(343, 270);
            dataGridCompanyPartner.TabIndex = 27;
            // 
            // FormCompanyPartner
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(32, 30, 45);
            ClientSize = new Size(693, 428);
            Controls.Add(lblChildForm);
            Controls.Add(btnLoad);
            Controls.Add(btnX);
            Controls.Add(dataGridCompanyPartner);
            Name = "FormCompanyPartner";
            Text = "FormCompanyPartner";
            ((System.ComponentModel.ISupportInitialize)dataGridCompanyPartner).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblChildForm;
        private Button btnLoad;
        private Button btnX;
        private DataGridView dataGridCompanyPartner;
    }
}