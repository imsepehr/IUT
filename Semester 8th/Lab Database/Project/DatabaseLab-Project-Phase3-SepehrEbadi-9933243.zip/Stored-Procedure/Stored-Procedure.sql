USE [Database-Lab]
GO

---1
CREATE PROCEDURE Select_All_CEO_Of_Companies
AS
SELECT * FROM Employees
WHERE Position = 'CEO'

EXEC Select_All_CEO_Of_Companies;

---2
CREATE PROCEDURE Count_Company1_Festivals
AS
SELECT COUNT(Company_ID) 
FROM Festival_Participants
WHERE Company_ID = 2

EXEC Count_Company1_Festivals;

---3
DROP PROCEDURE IF EXISTS Select_All_Companies_Participate_In_Food_Festival;  
GO  


CREATE PROCEDURE Select_All_Companies_Participate_In_Food_Festival
AS
SELECT DISTINCT(Company_ID) FROM Festival_Participants INNER JOIN Festivals ON Festivals.Festival_ID = Festival_Participants.Festival_ID
WHERE Festivals.Subject = 'Food'

EXEC Select_All_Companies_Participate_In_Food_Festival;
