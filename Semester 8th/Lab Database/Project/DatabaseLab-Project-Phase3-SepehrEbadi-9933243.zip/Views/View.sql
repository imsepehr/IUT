---1
CREATE VIEW EmployeeCompanyView AS
SELECT E.Employee_ID, E.First_Name, E.Last_Name, E.Phone, E.Email, E.Position, E.Salary, C.Name AS Company_Name
FROM Employees E
JOIN Companies C ON E.Company_ID = C.Company_ID;

SELECT * FROM EmployeeCompanyView;

---2
CREATE VIEW AverageSalaryByCompany AS
SELECT Company_ID, AVG(Salary) AS AverageSalary
FROM Employees
GROUP BY Company_ID;

SELECT * FROM AverageSalaryByCompany;

---3
DROP VIEW IF EXISTS HighEarningEmployees; 

CREATE VIEW HighEarningEmployees AS
SELECT E.*
FROM Employees E
JOIN (
    SELECT Company_ID, AVG(Salary) AS AvgSalary
    FROM Employees
    GROUP BY Company_ID
) AS AvgSalaries
ON E.Company_ID = AvgSalaries.Company_ID
WHERE E.Salary > AvgSalaries.AvgSalary;


SELECT * FROM HighEarningEmployees;

