﻿
DROP TABLE IF EXISTS Companies;
DROP TABLE IF EXISTS Employees;
DROP TABLE IF EXISTS Managers;
DROP TABLE IF EXISTS Festivals;
DROP TABLE IF EXISTS Festival_Participants;
DROP TABLE IF EXISTS Exhibitions;
DROP TABLE IF EXISTS Exhibition_Participants;
DROP TABLE IF EXISTS International_Visits;
DROP TABLE IF EXISTS Visit_Participants;
DROP TABLE IF EXISTS Research_Units;
DROP TABLE IF EXISTS Equipment_Facilities;
DROP TABLE IF EXISTS Industrial_Partners;
DROP TABLE IF EXISTS Company_Partners;
DROP TABLE IF EXISTS Facilities;
DROP TABLE IF EXISTS Loans_Taken;


-- ساخت جدول شرکت‌ها
CREATE TABLE Companies (
    Company_ID INT NOT NULL PRIMARY KEY IDENTITY(1,1),
	Name VARCHAR(255) NOT NULL,
    Field VARCHAR(255) NOT NULL,
    [Address] VARCHAR(255),
    Phone VARCHAR(20) NOT NULL,
    Website VARCHAR(255),
	Budget FLOAT 
);

-- ساخت جدول کارمندان
CREATE TABLE Employees (
    Employee_ID INT NOT NULL PRIMARY KEY IDENTITY(1,1),
    First_Name VARCHAR(100) NOT NULL,
    Last_Name VARCHAR(100) NOT NULL,
    Phone VARCHAR(20) NOT NULL,
    Email VARCHAR(255),
    Position VARCHAR(100) NOT NULL CHECK (Position IN ('CEO','EMP')),
	Salary FLOAT,
    Company_ID INT,
    FOREIGN KEY (Company_ID) REFERENCES Companies(Company_ID)
);

---- ساخت جدول مدیران و هیئت مدیره شهرک 
CREATE TABLE Managers (
    Manager_ID INT NOT NULL PRIMARY KEY IDENTITY(1,1),
    First_Name VARCHAR(100) NOT NULL,
    Last_Name VARCHAR(100) NOT NULL,
	Phone VARCHAR(20) NOT NULL,
    Email VARCHAR(255),
    Position VARCHAR(100) NOT NULL,
	Salary FLOAT,
);

-- ساخت جدول جشنواره‌ها
CREATE TABLE Festivals (
    Festival_ID INT NOT NULL PRIMARY KEY IDENTITY(1,1),
	Subject VARCHAR(255) NOT NULL,
    Name VARCHAR(255) NOT NULL,
    Description VARCHAR(255),
    Date DATE,
    Location VARCHAR(255)
);

-- جدول مشخص کننده ارتباط شرکت‌ها و جشنواره‌ها (به صورت یک به چند)
CREATE TABLE Festival_Participants (
    Festival_ID INT,
    Company_ID INT,
    PRIMARY KEY (Festival_ID, Company_ID),
    FOREIGN KEY (Festival_ID) REFERENCES Festivals(Festival_ID),
    FOREIGN KEY (Company_ID) REFERENCES Companies(Company_ID)
);

-- ساخت جدول نمایشگاه‌ها
CREATE TABLE Exhibitions (
    Exhibition_ID INT NOT NULL PRIMARY KEY IDENTITY(1,1),
    Name VARCHAR(255) NOT NULL,
	Field VARCHAR(255) NOT NULL,
    Description VARCHAR(255),
    Date DATE,
    Location VARCHAR(255)
);

-- جدول مشخص کننده ارتباط شرکت‌ها و نمایشگاه‌ها (به صورت یک به چند)
CREATE TABLE Exhibition_Participants (
    Exhibition_ID INT,
    Company_ID INT,
    PRIMARY KEY (Exhibition_ID, Company_ID),
    FOREIGN KEY (Exhibition_ID) REFERENCES Exhibitions(Exhibition_ID),
    FOREIGN KEY (Company_ID) REFERENCES Companies(Company_ID)
);

-- ساخت جدول بازدیدهای برون مرزی
CREATE TABLE International_Visits (
    Visit_ID INT NOT NULL PRIMARY KEY IDENTITY(1,1),
    Host_Country VARCHAR(100) NOT NULL,
    Description VARCHAR(255),
    Date DATE
);

-- جدول مشخص کننده ارتباط شرکت‌ها و بازدیدهای برون مرزی (به صورت یک به چند)
CREATE TABLE Visit_Participants (
    Visit_ID INT,
    Company_ID INT,
    PRIMARY KEY (Visit_ID, Company_ID),
    FOREIGN KEY (Visit_ID) REFERENCES International_Visits(Visit_ID),
    FOREIGN KEY (Company_ID) REFERENCES Companies(Company_ID)
);

-- ساخت جدول واحدهای تحقیقاتی
CREATE TABLE Research_Units (
    Unit_ID INT NOT NULL PRIMARY KEY IDENTITY(1,1),
    Name VARCHAR(255) NOT NULL,
    Description VARCHAR(255),
    Manager_ID INT,
    FOREIGN KEY (Manager_ID) REFERENCES Managers(Manager_ID)
);

-- ساخت جدول تجهیزات و امکانات
CREATE TABLE Equipment_Facilities (
    Equipment_ID INT NOT NULL PRIMARY KEY IDENTITY(1,1),
    Name VARCHAR(255) NOT NULL,
    Description VARCHAR(255),
    Units_Available INT NOT NULL,
    Maintenance_Status VARCHAR(100) NOT NULL,
    Unit_ID INT,
    FOREIGN KEY (Unit_ID) REFERENCES Research_Units(Unit_ID)
);

-- ساخت جدول همکاران صنعتی
CREATE TABLE Industrial_Partners (
    Partner_ID INT NOT NULL PRIMARY KEY IDENTITY(1,1),
    Name VARCHAR(255) NOT NULL,
    Description VARCHAR(255),
    Contact_Info VARCHAR(255)
);

-- جدول مشخص کننده ارتباط شرکت‌ها و همکاران صنعتی (به صورت یک به چند)
CREATE TABLE Company_Partners (
    Company_ID INT,
    Partner_ID INT,
    PRIMARY KEY (Company_ID, Partner_ID),
    FOREIGN KEY (Company_ID) REFERENCES Companies(Company_ID),
    FOREIGN KEY (Partner_ID) REFERENCES Industrial_Partners(Partner_ID)
);

-- ساخت جدول تسهیلات
CREATE TABLE Facilities (
    Facility_ID INT NOT NULL PRIMARY KEY IDENTITY(1,1),
    Name VARCHAR(255) NOT NULL,
    Type VARCHAR(100) NOT NULL,
    Interest_Rate FLOAT NOT NULL
);

-- ساخت جدول تسهیلات گرفته شده
CREATE TABLE Loans_Taken (
    Loan_ID INT NOT NULL PRIMARY KEY IDENTITY(1,1),
    Company_ID INT,
    Facility_ID INT,
    Amount DECIMAL(18,2),
    Duration INT,
    Borrower VARCHAR(255),
    FOREIGN KEY (Company_ID) REFERENCES Companies(Company_ID),
    FOREIGN KEY (Facility_ID) REFERENCES Facilities(Facility_ID)
);
